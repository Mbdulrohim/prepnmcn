/**
 * AWS Lambda Function: Email Processor for O'Prep
 *
 * This function is triggered when SES receives an email.
 * It downloads the email from S3, parses it, and sends it to your webhook.
 *
 * Required Environment Variables:
 * - WEBHOOK_URL: Your app's webhook endpoint
 * - WEBHOOK_SECRET: Secret for webhook authentication
 */

const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { simpleParser } = require('mailparser');
const crypto = require('crypto');

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'eu-north-1' });

/**
 * Lambda handler - triggered by SES
 */
exports.handler = async (event) => {
  console.log('Received SES event:', JSON.stringify(event, null, 2));

  try {
    // Extract email metadata from SES event
    const sesRecord = event.Records[0].ses;
    const mail = sesRecord.mail;
    const receipt = sesRecord.receipt;

    console.log('Processing email:', {
      messageId: mail.messageId,
      from: mail.source,
      to: mail.destination,
      timestamp: mail.timestamp,
    });

    // Get S3 location from receipt action
    const s3Action = receipt.action.type === 'S3' ? receipt.action : null;
    if (!s3Action) {
      throw new Error('No S3 action found in receipt');
    }

    const bucketName = s3Action.bucketName;
    const objectKey = s3Action.objectKey;

    console.log('Fetching email from S3:', { bucketName, objectKey });

    // Download email from S3
    const s3Response = await s3Client.send(
      new GetObjectCommand({
        Bucket: bucketName,
        Key: objectKey,
      })
    );

    // Convert stream to string
    const emailContent = await streamToString(s3Response.Body);

    // Parse the email using mailparser
    const parsed = await simpleParser(emailContent);

    console.log('Email parsed successfully:', {
      subject: parsed.subject,
      from: parsed.from?.text,
      to: parsed.to?.text,
      attachmentCount: parsed.attachments?.length || 0,
    });

    // Extract attachments metadata
    const attachments = (parsed.attachments || []).map((att) => ({
      filename: att.filename,
      contentType: att.contentType,
      size: att.size,
      contentId: att.contentId,
      // We'll store the actual file in S3 separately if needed
      // For now, just metadata
    }));

    // Build webhook payload
    const webhookPayload = {
      messageId: mail.messageId,
      from: parsed.from?.text || mail.source,
      to: parsed.to?.text || mail.destination.join(', '),
      cc: parsed.cc?.text || null,
      bcc: parsed.bcc?.text || null,
      subject: parsed.subject || '(No Subject)',
      htmlBody: parsed.html || null,
      textBody: parsed.text || null,
      receivedAt: new Date(mail.timestamp).toISOString(),
      headers: parsed.headers || {},
      s3Bucket: bucketName,
      s3Key: objectKey,
      attachments: attachments,
      inReplyTo: parsed.inReplyTo || null,
      references: parsed.references || null,
      spamScore: receipt.spamVerdict?.status === 'PASS' ? 0 : 5,
      virusStatus: receipt.virusVerdict?.status || 'UNKNOWN',
      spfStatus: receipt.spfVerdict?.status || 'UNKNOWN',
      dkimStatus: receipt.dkimVerdict?.status || 'UNKNOWN',
      dmarcStatus: receipt.dmarcVerdict?.status || 'UNKNOWN',
    };

    console.log('Sending to webhook:', process.env.WEBHOOK_URL);

    // Send to webhook with signature
    const response = await sendToWebhook(webhookPayload);

    console.log('Webhook response:', response.status, response.statusText);

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Webhook failed: ${response.status} - ${errorText}`);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Email processed successfully',
        messageId: mail.messageId,
      }),
    };
  } catch (error) {
    console.error('Error processing email:', error);

    // Log error but don't throw - we don't want SES to retry
    // Instead, you might want to:
    // 1. Store in DLQ (Dead Letter Queue)
    // 2. Send alert to monitoring
    // 3. Store error in database

    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Error processing email',
        error: error.message,
      }),
    };
  }
};

/**
 * Send parsed email to webhook
 */
async function sendToWebhook(payload) {
  const webhookUrl = process.env.WEBHOOK_URL;
  const webhookSecret = process.env.WEBHOOK_SECRET;

  if (!webhookUrl) {
    throw new Error('WEBHOOK_URL environment variable not set');
  }

  // Create HMAC signature for security
  const signature = crypto
    .createHmac('sha256', webhookSecret || 'fallback-secret')
    .update(JSON.stringify(payload))
    .digest('hex');

  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Webhook-Signature': signature,
      'User-Agent': 'AWS-Lambda-Email-Processor/1.0',
    },
    body: JSON.stringify(payload),
  });

  return response;
}

/**
 * Convert stream to string
 */
async function streamToString(stream) {
  const chunks = [];

  for await (const chunk of stream) {
    chunks.push(chunk);
  }

  return Buffer.concat(chunks).toString('utf-8');
}
